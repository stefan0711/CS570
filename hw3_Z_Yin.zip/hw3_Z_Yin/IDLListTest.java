package com.yzp;

/**
 * @author Zhipeng Yin
 * @date 2021-03-23 23:35
 */
public class IDLListTest {
    public static void main(String[] args) {
        IDLList<String> idlList = new IDLList<String>();
        idlList.add(0,"Mike");
        idlList.add(1,"Mary");
        idlList.add(2,"Jerry");
        idlList.add(3,"Tom");
        idlList.add(4,"Jerry");
        idlList.append("Zhipeng");
        idlList.add("Sherry");
        idlList.add("Stevens");
    //    idlList.add(null);

        System.out.println("Show the size of the list --->");
        System.out.println(idlList.size());
        System.out.println("Print the list ---->");
        System.out.println(idlList.toString());
        System.out.println("Show index 3 --->");
        System.out.println(idlList.get(3));
        System.out.println("Show the head --->");
        System.out.println(idlList.getHead());
        System.out.println("Show the tail --->");
        System.out.println(idlList.getLast());

        System.out.println("Remove index 2 --->");
        idlList.removeAt(2);
        System.out.println(idlList.toString());

        System.out.println("Remove the head --->");
        idlList.remove();
        System.out.println(idlList.toString());

        System.out.println("Remove the tail --->");
        idlList.removeLast();
        System.out.println(idlList.toString());

        System.out.println("Remove the Jerry --->");
        idlList.remove("Jerry");
        System.out.println(idlList.toString());

        System.out.println("Remove Empty Nodes -->");
        idlList.remove(null);
        System.out.println(idlList.toString());

        System.out.println(idlList.size());

    }
}
