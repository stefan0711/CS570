package com.yzp;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * @author Zhipeng Yin
 * @date 2021-03-19 23:22
 */
public class IDLList<E> {

    private static class Node<E>{
        private E data;
        private Node<E> next;
        private Node<E> prev;

        public Node(E elem){
            data = elem;
            next = null;
            prev = null;
        }

        public Node(E elem,Node<E> prev,Node<E> next){
            data = elem;
            this.next = next;
            this.prev = prev;
        }
    }

    private Node<E> head;

    private Node<E> tail;

    private int size;

    private ArrayList<Node<E>> indices;

    public IDLList(){
       head = null;
       tail = null;
       indices = new ArrayList<Node<E>>();
       size = 0;

    }

    public boolean add (E elem){
        if (elem == null){
            throw new RuntimeException("The added data cannot be empty!");
        }
        Node<E> node = new Node<E>(elem);
        if (head == null){
            head = node;
            tail = node;
        }else {
            head.prev = node;
            node.next = head;
            head = node;
        }
        indices.add(0,node);
        size++;
        return true;
    }

    public boolean append(E elem){
        if (elem == null){
            throw new RuntimeException("The added data cannot be empty!");
        }
        Node<E> node = new Node<E>(elem);
        if (head == null){
            head = node;
        }else {
            tail.next = node;
            node.prev = tail;
        }
        tail = node;
        indices.add(node);
        size++;
        return true;
    }

    public boolean add (int index, E elem){
        if (index < 0 || index > size){
            throw new RuntimeException("index is out of bounds!");
        }else {
            if (index == 0){           //Add the head
                add(elem);
            }else if (index == size){   // Add the tail
                append(elem);
            }else {
                if (elem == null){
                    throw new RuntimeException("The added data cannot be empty!");
                }
                Node<E> newNode = new Node<E>(elem);
                Node<E> pre = indices.get(index-1);
                Node<E> next = indices.get(index);
                pre.next = newNode;
                next.prev = newNode;
                newNode.prev = pre;
                newNode.next = next;
                size++;
                indices.add(index,newNode);
            }
        }
        return true;
    }

    public E get(int index){
        if (index < 0 || index >= size){
            throw new RuntimeException("index is out of bounds!");
        }else {
            Node<E> node = indices.get(index);
            return node.data;
        }
    }

    public E getHead(){
        if (size == 0){
            throw new RuntimeException("double-linked list is empty!");
        }else {
            return head.data;
        }
    }

    public E getLast(){
        if (size == 0){
            throw new RuntimeException("double-linked list is empty!");
        }else {
            return tail.data;
        }
    }

    public int size(){
        return size;
    }

    public E remove(){
        if (size == 0){
            throw new RuntimeException("double-linked list is empty!");
        }else {
            E preHead = head.data;
            head = head.next;
            indices.remove(0);
            size--;
            if (head == null) {    //List is empty after deleting head(only one node)
                tail = null;
            } else {
                head.prev = null;
            }
            return preHead;
        }
    }

    public E removeLast(){
        if (size == 0){
            throw new RuntimeException("double-linked list is empty!");
        }else {
            E preLast = tail.data;
            tail = tail.prev;
            indices.remove(size-1);
            size--;
            if (tail == null){   //List is empty after deleting tail
                head = null;
            }else {
                tail.next = null;
            }
            return preLast;
        }
    }

    public E removeAt(int index){
        if (size == 0){
            throw new RuntimeException("double-linked list is empty!");
        }else {

            if (index < 0 || index >= size){
                throw new RuntimeException("index is out of bounds!");
            }else {
                E removeData = indices.get(index).data;
                if (index == 0){        //Remove head
                    remove();
                }else if (index == size-1){   //Remove tail
                    removeLast();
                }else {                        //Remove others
                    Node<E> pre = indices.get(index-1);
                    Node<E> next = indices.get(index+1);
                    pre.next = next;
                    next.prev = pre;
                    indices.remove(index);
                    size--;
                }
                return removeData;
            }

        }
    }

    public boolean remove (E elem){
        for (int i = 0; i <size ; i++) {    //Searching for the same element
            if (indices.get(i).data == elem){
                removeAt(i);
                return true;
            }
        }
        return false;
    }

    public String toString(){
        String str = "";
        for (int i = 0; i < size; i++) {
            str = str + indices.get(i).data.toString() + " ";
        }
        return str;
    }
}
