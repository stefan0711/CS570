package com.yzp.hw5;

import java.util.Random;
import java.util.Stack;

/**
 * @author Zhipeng Yin
 * @date 2021-04-23 11:35
 */
public class Treap<E extends Comparable<E>> {

    private static class Node<E>{
        public E data;
        public int priority;
        public Node<E> left;
        public Node<E> right;

        public Node(E data, int priority){
            if (data == null){
                throw new RuntimeException("Data cannot be null!");
            }
            this.data=data;
            this.priority = priority;
            left = null;
            right = null;
        }

        Node<E> rotateRight (){
            Node<E> temp = this.left;
            Node<E> left = temp.right;
            temp.right = this;
            this.left = left;
            return temp;
        }
        Node<E> rotateLeft (){
            Node<E> temp = this.right;
            Node<E> right = temp.left;
            temp.left = this;
            this.right = right;
            return temp;
        }
    }

    private Random priorityGenerator;
    private Node<E> root;

    public Treap(){
        priorityGenerator = new Random();
        root = null;
    }

    public Treap(long seed){
        priorityGenerator = new Random(seed);
        root = null;
    }

    boolean add(E key){
        if (key == null){
            throw new RuntimeException("Key cannot be null!");
        }
        return add(key,priorityGenerator.nextInt());
    }

    boolean add(E key,int priority){
        if (key == null){
            throw new RuntimeException("Key cannot be null!");
        }
        if (root == null) {
            root = new Node<E>(key, priority);
            return true;
        } else {
            Stack<Node<E>> stack = new Stack<>();
            Node<E> nRoot = new Node<E>(key, priority);
            Node<E> tRoot = root;
            while (tRoot != null) {
                if (tRoot.data.compareTo(key) == 0) {          //Case of equality
                    return false;
                } else {
                    if (tRoot.data.compareTo(key) < 0) {       //Add to the right child
                        stack.push(tRoot);
                        if (tRoot.right == null) {
                            tRoot.right = nRoot;
                            reHeap(nRoot, stack);
                            return true;
                        } else {
                            tRoot = tRoot.right;
                        }
                    } else {                                    //Add to the left child
                        stack.push(tRoot);
                        if (tRoot.left == null) {
                            tRoot.left = nRoot;
                            reHeap(nRoot, stack);
                            return true;
                        } else {
                            tRoot = tRoot.left;
                        }
                    }
                }
            }
            return false;
        }
    }

    private void reHeap(Node<E> child, Stack<Node<E>> stack) {
        while (!stack.isEmpty()) {
            Node<E> parent = stack.pop();
            if (parent.priority < child.priority) {               //Judge the node priority
                if (parent.data.compareTo(child.data) > 0) {
                    child = parent.rotateRight();
                } else {
                    child = parent.rotateLeft();
                }
                if (!stack.isEmpty()) {
                    if (stack.peek().left == parent) {
                        stack.peek().left = child;
                    } else {
                        stack.peek().right = child;
                    }
                } else {
                    this.root = child;
                }
            } else {
                break;
            }
        }
    }

    boolean delete(E key) {
        if (!find(key) || root == null) {
            return false;
        } else {
            root = delete(key, root);
            return true;
        }
    }

    //This is the private method to help delete
    private Node<E> delete(E key, Node<E> tRoot){
        if (tRoot == null) {
            return tRoot;
        } else {
            if (tRoot.data.compareTo(key) < 0) {
                tRoot.right = delete(key, tRoot.right);
            } else {
                if (tRoot.data.compareTo(key) > 0) {
                    tRoot.left = delete(key, tRoot.left);
                } else {
                    if (tRoot.right == null) {
                        tRoot = tRoot.left;
                    } else if (tRoot.left == null) {
                        tRoot = tRoot.right;
                    } else {
                        if (tRoot.right.priority < tRoot.left.priority) {      //Compare the priorities of the two children
                            tRoot = tRoot.rotateRight();
                            tRoot.right = delete(key, tRoot.right);
                        } else {
                            tRoot = tRoot.rotateLeft();
                            tRoot.left = delete(key, tRoot.left);
                        }
                    }
                }
            }
        }
        return tRoot;
    }

    boolean find(E key){
        if (key == null){
            throw new RuntimeException("Key cannot be null!");
        }
        return find(root,key);
    }

    private boolean find(Node<E> root,E key){
        if(root==null) {
            return false;
        }
        if(key.compareTo(root.data) == 0) {
            return true;
        }
        else if(key.compareTo(root.data) < 0) {     //Less than
            return find(root.left,key);             //Recursive query for the left subtree
        }
        else {
            return find(root.right,key);
        }
    }

    private void preOrderTraverse(Node<E> node, int depth, StringBuilder strbuilder) {
        for (int i = 1; i < depth; i++) {
            strbuilder.append("  ");
        }
        if (node == null) {
            strbuilder.append("null\n");
        }
        else {
            strbuilder.append("(key = ").append(node.data).append(", priority = ").append(node.priority).append(")").append("\n");
            preOrderTraverse(node.left, depth + 1, strbuilder);
            preOrderTraverse(node.right, depth + 1, strbuilder);
        }
    }

    public String toString(){
        StringBuilder stringBuilder = new StringBuilder();
        preOrderTraverse(root,1,stringBuilder);
        return stringBuilder.toString();
    }

    public static void main(String[] args) {
        Treap<Integer> treap = new Treap<>();           //Test 1
        treap.add(4,19);
        treap.add(2,31);
        treap.add(6,70);
        treap.add(1,84);
        treap.add(3,12);
        treap.add(5,83);
        treap.add(7,26);
        System.out.println(treap);
        System.out.println("Delete 2 node: "+ treap.delete(2));     //Test for deleting a node
        System.out.println("find 3 : "+ treap.find(3));             //Finding test
        System.out.println("find 2 : "+treap.find(2));
        System.out.println(treap);

        Treap<String> stringTreap = new Treap<>();      //Test 2
        stringTreap.add("Mary",39);
        stringTreap.add("Victor",21);
        stringTreap.add("Mike",23);
        stringTreap.add("Lily",67);
        stringTreap.add("Zhipeng",1);
        stringTreap.add("Bob",21);
        stringTreap.add("Tom");
        System.out.println(stringTreap);
        System.out.println("Delete Bob ");
        stringTreap.delete("Bob");
        System.out.println("Find Bob "+stringTreap.find("Bob"));
        System.out.println(stringTreap);
    }
}
