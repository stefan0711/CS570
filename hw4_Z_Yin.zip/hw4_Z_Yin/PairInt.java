package com.yzp.hw4;

/**
 * @author Zhipeng Yin
 * @date 2021-04-10 00:27
 */
public class PairInt {
    private int x;
    private int y;

    public PairInt(int x, int y){
        if (x<0||y<0){
            throw new  RuntimeException("The argument cannot be negative");
        }
        this.x=x;
        this.y=y;
    }

    public int getX(){
       return x;
    }

    public int getY(){
        return y;
    }

    public void setX(int x){
        if (x<0){
            throw new  RuntimeException("The argument cannot be negative");
        }
        this.x=x;
    }

    public void setY(int y){
        if (y<0){
            throw new  RuntimeException("The argument cannot be negative");
        }
        this.y=y;
    }

    public boolean equals(Object p){
        if (p==null){
            return false;
        }
        PairInt pairInt = (PairInt) p;
        if (pairInt.getX()==x && pairInt.getY()==y){
            return true;
        }
        return false;
    }

    public String toString(){
        return "("+x+""+","+y+""+")";
    }

    public PairInt copy(){
        return new PairInt(x,y);
    }

}
