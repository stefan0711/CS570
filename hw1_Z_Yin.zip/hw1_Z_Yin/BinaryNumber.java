package com.yzp;

import java.util.Arrays;

import static java.util.Arrays.copyOf;

/**
 * @Author Zhipeng Yin
 * @Date 2021-02-20 15:02
 */
public class BinaryNumber {

    private int[] data;

    private boolean overflow;

    public BinaryNumber(String str) {
        if (str == null||str.length()<=0){
            System.out.println("The input string is empty and the default input binary number is 0");
            data = new int[1];
        }else {
            data = new int[str.length()];
            for (int i = 0; i < str.length(); i++) {
                data[i] = Character.getNumericValue(str.charAt(i));
            }
        }
    }

    public BinaryNumber(int length) {
        data = new int[length];
    }

    public int getLength(){
        return data.length;
    }

    public int getDigit(int index){
        int num = -1;
        if (index<0||index>data.length-1){
            System.out.println("index is out of bounds,return -1");
        }else {
            num = data[index];
        }
        return num;
    }

    public int toDecimal(){
        int decimal = 0;
        for (int i = 0; i < data.length ; i++) {
            decimal = decimal + data[i]*(int)Math.pow(2,i);
        }
        return decimal;
    }

    public void shiftR(int amount){
         reallocate(data);
         data = copyOf(data,data.length+amount);
         reallocate(data);
    }

    /**
     * this method
     * An array of reverse
     **/
    private void reallocate(int[] newData){
        for (int i = 0; i <newData.length/2 ; i++) {
            int temp = newData[newData.length-i-1];
            newData[newData.length-i-1] = newData[i];
            newData[i] = temp;
        }
    }

    void add(BinaryNumber aBinaryNumber){
        if (aBinaryNumber.data.length!=data.length){
            System.out.println("the lengths of the binary numbers do not coincide!");
        }else {
            int[] newNum = new int[data.length];
            int carriedDig = 0;
            for (int i = 0; i <data.length ; i++) {
               int newDig = data[i]+aBinaryNumber.data[i]+carriedDig;
               if (newDig==1){
                   newNum[i] = 1;
                   carriedDig = 0;
               }else if (newDig>=2&&(newDig%2==0)){
                   newNum[i] =  0;
                   carriedDig = 1;
               }else if (newDig>=2&&(newDig%2==1)){
                   newNum[i] = 1;
                   carriedDig = 1;
               }
               //Check for overflow
               if (data[data.length-1]+aBinaryNumber.data[data.length-1]+carriedDig>=2){
                   overflow = true;
               }
            }
            if (!overflow) {
                data = newNum;
            }else {
                int[] overflowNum = Arrays.copyOf(newNum,data.length+1);
                overflowNum[data.length] = 1;
                data = overflowNum;
            }
        }
    }

    public void clearOverflow(){
        overflow = false;
    }

    public String toString(){
        String strData = "";
        if(overflow){
            strData = "overflow";
        }else {
            for (int datum : data) {
                strData = strData + String.valueOf(datum);
            }
        }
        return strData;
    }

    /**
     * The main method is used to test
     * */
    public static void main(String[] args) {
        BinaryNumber binaryNumber = new BinaryNumber("10011");
        System.out.println(binaryNumber.getDigit(2));
        System.out.println(binaryNumber.toDecimal());
        binaryNumber.shiftR(4);
        System.out.println(binaryNumber.toString());
 //       binaryNumber.add(new BinaryNumber("000111"));
       System.out.println(Arrays.toString(binaryNumber.data));
    }
}
