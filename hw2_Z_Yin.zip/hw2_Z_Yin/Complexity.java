package com.yzp;

/**
 * @author Zhipeng Yin
 * @date 2021-02-26 23:11
 */
public class Complexity {
    //complexity O(n^2)
    public static void method1(int n){
        int count = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                System.out.println("Operation"+count);
                count++;
            }
        }
    }

    //complexity O(n^3)
    public static void method2(int n){
        int count = 0;
        for (int i = 0; i <n; i++) {
            for (int j = 0; j < n; j++) {
                for (int k = 0; k < n; k++) {
                    System.out.println("Operation"+count);
                    count++;
                }
            }
        }
    }

    //complexity O(logn)
    public static void method3(int n){
        int count = 0;
        while (n>1){
            System.out.println("Operation"+count);
            count++;
            n=n/2;
        }
    }

    //complexity O(nlogn)
    public static void method4(int n){
        int count = 0;
        for (int i = 0; i < n; i++) {
            int j = n;
            while (j>1){
                System.out.println("Operation"+count);
                count++;
                j=j/2;
            }
        }
    }

    //complexity O(loglogn)
    public static void method5(int n){
        int count = 0;
        int j = 2;
        while (j < n) {
            System.out.println("Operation"+count);
            count++;
            j = j * j;
        }
    }

    //complexity O(2^n)
    public static int method6(int n){
            if (n <=1) {
                return n;
            } else {
                return method6(n - 1) + method6(n - 2);
        }
    }

    /**
     * This method is used to test.
     */
    public static void main(String[] args) {
      //  method1(0);
      //  method2(2);
      //  method3(16);
        method4(4);
      //  method5(2);
      //  System.out.println(method6(3));
    }
}
