package com.yzp.hw6;

import java.io.*;
import java.util.*;

/**
 * @author Zhipeng Yin
 * @date 2021-04-26 18:24
 */
public class Anagrams {
    final Integer[] primes = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61,
            67, 71, 73, 79, 83, 89, 97, 101};
    Map<Character,Integer> letterTable;
    Map<Long, ArrayList<String>> anagramTable;

    public Anagrams (){
         buildLetterTable();
         anagramTable = new HashMap<>();
    }

    private void buildLetterTable(){
        letterTable = new HashMap<>();
        List<Character> arrayList = new ArrayList<>();
        for (int i = 'a';i<='z';i++){
          arrayList.add((char)i);                           //Get a list of 26 letters
        }
        for (int i = 0; i < 26; i++) {
          letterTable.put(arrayList.get(i),primes[i]);      //Letters correspond to numbers
        }
    }

    private void processFile(String s) throws IOException {
        if (s == null){
            throw new RuntimeException("s cannot be null!");
        }
        FileInputStream fStream = new FileInputStream(s);
        BufferedReader br = new BufferedReader( new InputStreamReader(fStream));
        String strLine;
        while (( strLine = br. readLine ()) != null ) {
            this.addWord(strLine);
        }
        br.close ();
    }

    private Long myHashCode(String s){
        if (s == null){
            throw new RuntimeException("s cannot be null!");
        }
        Long hashCode = 1L;
        for (int i = 0; i <s.length(); i++) {
            hashCode= hashCode * letterTable.get(s.charAt(i));   //Calculate the number for each letter
        }
        return hashCode;
    }

    private ArrayList<Map.Entry<Long,ArrayList<String>>> getMaxEntries(){
        ArrayList<Long> list = new ArrayList<>(anagramTable.keySet());
        List<Integer> sizeList = new ArrayList<>();
        for (long n: list) {                                //Iterate through the list of anagramTable's keys
            sizeList.add(anagramTable.get(n).size());       //Gets the size of the List of Anagrams and places it in the List
        }
        sizeList.sort(Comparator.reverseOrder());
        int maxSize = sizeList.get(0);                      //Reverse order and gets the size of the list of max Anagrams
        Map<Long,ArrayList<String>> maxWordMap = new HashMap<>();
        for (long i:list) {
            if (anagramTable.get(i).size()==maxSize){
                maxWordMap.put(i,anagramTable.get(i));      //Put key and list of max anagrams into the map
            }
        }
        return new ArrayList<>(maxWordMap.entrySet());
    }

    private void addWord(String s){
        if (s == null){
            throw new RuntimeException("s cannot be null!");
        }
        Long hashCode = myHashCode(s);
        if (anagramTable.get(hashCode)==null||anagramTable.get(hashCode).size()==0){  //If the list for this hashcode has not been created
            ArrayList<String> list = new ArrayList<>();
            list.add(s);
            anagramTable.put(hashCode,list);   //Updates anagramTable
        } else {
            anagramTable.get(hashCode).add(s);  //list has been created
            anagramTable.put(hashCode,anagramTable.get(hashCode));
        }
    }

    public static void main(String[] args) {
        Anagrams a = new Anagrams();
        final long startTime = System.nanoTime();
        try {
            // System.out.println( System.getProperty("user.dir"));
            // System.out.println(new File(".").getAbsolutePath());
            a.processFile("words_alpha.txt");
        }catch(IOException e1){
            e1.printStackTrace();
        }
        ArrayList < Map.Entry < Long , ArrayList < String >>> maxEntries = a.getMaxEntries();
        final long estimatedTime = System.nanoTime() - startTime;
        final double seconds = (( double ) estimatedTime / 1000000000 ) ;
        System.out.println (" Time : "+ seconds );
        System.out.println(" Key of max anagrams : "+maxEntries.get(0).getKey());
        System.out.println (" List of max anagrams : "+ maxEntries.get(0).getValue() );
        System.out.println (" Length of list of max anagrams : " + maxEntries.get(0).getValue().size());
    }

}
